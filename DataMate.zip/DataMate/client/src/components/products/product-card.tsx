import { cn, formatPrice, truncateText } from "@/lib/utils";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ProductImage } from "@/components/ui/product-image";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { Product } from "@shared/schema";
import { Link } from "wouter";
import { useCart } from "@/hooks/use-cart";
import { getDefaultProductImage } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  className?: string;
}

export function ProductCard({ product, className }: ProductCardProps) {
  const { addToCart } = useCart();
  const { id, title, price, description, imageUrl, stock } = product;
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };
  
  return (
    <Link href={`/product/${id}`}>
      <Card className={cn("overflow-hidden transition-all hover:shadow-md", className)}>
        <ProductImage
          src={imageUrl || getDefaultProductImage(id)}
          alt={title}
          aspectRatio={4/3}
          className="object-cover"
          fallbackSrc={getDefaultProductImage(id)}
        />
        <CardContent className="p-4">
          <div className="space-y-1">
            <h3 className="font-medium text-lg leading-tight">{title}</h3>
            <p className="text-sm text-muted-foreground">
              {truncateText(description, 80)}
            </p>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between items-center">
          <div className="font-medium">{formatPrice(price)}</div>
          <Button 
            variant="secondary" 
            size="sm" 
            className="h-8"
            onClick={handleAddToCart}
            disabled={stock < 1}
          >
            <ShoppingCart className="h-4 w-4 mr-1" />
            {stock < 1 ? "Out of stock" : "Add"}
          </Button>
        </CardFooter>
      </Card>
    </Link>
  );
}
