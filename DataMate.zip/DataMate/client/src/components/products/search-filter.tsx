import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, X } from "lucide-react";
import { useRouter } from "wouter/use-location";
import { useLocation } from "wouter";
import { PRODUCT_CATEGORIES } from "@shared/schema";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function SearchFilter() {
  const [, navigate] = useLocation();
  const location = useRouter();
  const searchParams = new URLSearchParams(location.search);
  
  const [searchQuery, setSearchQuery] = useState(searchParams.get("search") || "");
  const [category, setCategory] = useState(searchParams.get("category") || "");
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateFilters();
  };
  
  const handleCategoryChange = (value: string) => {
    setCategory(value);
    searchParams.set("category", value);
    
    // Remove search query when changing category
    if (searchQuery) {
      setSearchQuery("");
      searchParams.delete("search");
    }
    
    navigate(`/shop?${searchParams.toString()}`);
  };
  
  const handleClearFilters = () => {
    setSearchQuery("");
    setCategory("");
    navigate("/shop");
  };
  
  const updateFilters = () => {
    const params = new URLSearchParams();
    
    if (searchQuery) {
      params.set("search", searchQuery);
    }
    
    if (category) {
      params.set("category", category);
    }
    
    navigate(`/shop?${params.toString()}`);
  };
  
  // Update the URL when search query changes
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery) {
        searchParams.set("search", searchQuery);
        navigate(`/shop?${searchParams.toString()}`);
      } else if (searchParams.has("search")) {
        searchParams.delete("search");
        navigate(`/shop?${searchParams.toString()}`);
      }
    }, 500);
    
    return () => clearTimeout(timer);
  }, [searchQuery]);
  
  const hasFilters = searchQuery || category;
  
  return (
    <div className="mb-8 space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <form onSubmit={handleSearch} className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </form>
        
        <div className="w-full sm:w-48">
          <Select value={category} onValueChange={handleCategoryChange}>
            <SelectTrigger>
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Categories</SelectItem>
              {PRODUCT_CATEGORIES.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {hasFilters && (
          <Button variant="outline" size="icon" onClick={handleClearFilters}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>
      
      {hasFilters && (
        <div className="flex items-center text-sm">
          <span className="text-muted-foreground">Filters: </span>
          <div className="flex gap-2 ml-2">
            {searchQuery && (
              <div className="bg-muted rounded-full px-3 py-1 flex items-center">
                <span className="mr-1">"{searchQuery}"</span>
                <button 
                  onClick={() => setSearchQuery("")}
                  className="ml-1 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
            
            {category && (
              <div className="bg-muted rounded-full px-3 py-1 flex items-center">
                <span className="mr-1">{category}</span>
                <button 
                  onClick={() => handleCategoryChange("")}
                  className="ml-1 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
