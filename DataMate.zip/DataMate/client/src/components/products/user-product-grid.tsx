import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Plus } from "lucide-react";

interface UserProductGridProps {
  userId: number;
  onAddNew?: () => void;
}

export function UserProductGrid({ userId, onAddNew }: UserProductGridProps) {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', { sellerId: userId }],
    enabled: !!userId,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!products || products.length === 0) {
    return (
      <div className="text-center py-12 bg-muted/20 rounded-lg">
        <h3 className="text-lg font-medium mb-2">No Products Yet</h3>
        <p className="text-muted-foreground mb-4">
          You haven't added any handcrafted items yet.
        </p>
        <Button onClick={onAddNew}>
          <Plus className="mr-2 h-4 w-4" />
          Create Your First Product
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {products.map((product) => (
        <Link key={product.id} href={`/product/${product.id}`}>
          <div className="group cursor-pointer">
            <Card className="overflow-hidden h-48 transition-all border-2 hover:border-primary/50 group-hover:shadow-md">
              <img
                src={product.imageUrl || `https://placehold.co/300x300?text=${encodeURIComponent(product.title)}`}
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </Card>
            <div className="mt-2">
              <h3 className="font-medium text-sm line-clamp-1">{product.title}</h3>
              <p className="text-sm text-muted-foreground">${product.price.toFixed(2)}</p>
            </div>
          </div>
        </Link>
      ))}
      
      {/* Add new product button */}
      {onAddNew && (
        <div 
          onClick={onAddNew} 
          className="cursor-pointer h-48 rounded-md border-2 border-dashed flex items-center justify-center group hover:border-primary/50 transition-all"
        >
          <div className="text-center">
            <div className="mx-auto h-10 w-10 rounded-full bg-muted/30 flex items-center justify-center mb-2 group-hover:bg-primary/10">
              <Plus className="h-5 w-5 text-muted-foreground group-hover:text-primary" />
            </div>
            <span className="text-sm font-medium text-muted-foreground group-hover:text-primary">
              Add New
            </span>
          </div>
        </div>
      )}
    </div>
  );
}