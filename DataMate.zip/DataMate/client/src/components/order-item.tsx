import React from "react";
import { OrderItem as OrderItemType } from "@shared/schema";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

interface OrderItemProps {
  item: OrderItemType;
}

export default function OrderItem({ item }: OrderItemProps) {
  // Fetch product details to get the title and image
  const { data: product, isLoading } = useQuery({
    queryKey: [`/api/products/${item.productId}`],
    queryFn: async () => {
      const res = await fetch(`/api/products/${item.productId}`);
      if (!res.ok) {
        // If the product doesn't exist anymore, we'll still show the order item
        // but without the product details
        return null;
      }
      return res.json();
    },
  });

  return (
    <div className="flex items-center gap-4 p-3 border border-neutral-200 rounded-md">
      <div className="h-16 w-16 bg-neutral-100 rounded-md overflow-hidden flex-shrink-0">
        {isLoading ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="h-4 w-4 animate-spin text-neutral-400" />
          </div>
        ) : product ? (
          <img
            src={product.imageUrl}
            alt={product.title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex justify-center items-center h-full bg-neutral-200 text-neutral-400 text-xs">
            No image
          </div>
        )}
      </div>
      
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-neutral-900 truncate">
          {isLoading ? (
            <span className="animate-pulse">Loading...</span>
          ) : product ? (
            <Link href={`/product/${item.productId}`} className="hover:underline">
              {product.title}
            </Link>
          ) : (
            <span className="text-neutral-500">Product no longer available</span>
          )}
        </h4>
        <div className="text-sm text-neutral-500">
          <span>Quantity: {item.quantity}</span>
          <span className="mx-2">•</span>
          <span>Price: ${item.price.toFixed(2)}</span>
        </div>
      </div>
      
      <div className="text-right font-medium">
        ${(item.price * item.quantity).toFixed(2)}
      </div>
    </div>
  );
}
