import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "../hooks/use-auth";
import { useCart } from "../lib/cart";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Menu, X, ShoppingCart, User, LogOut, Package } from "lucide-react";
import { cn } from "@/lib/utils";
import { PRODUCT_CATEGORIES } from "@shared/schema";

export default function NavigationBar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { totalItems, setIsOpen: setCartOpen } = useCart();
  const [scrolled, setScrolled] = useState(false);

  // Handle scroll for nav bar appearance
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Format username for display
  const formatDisplayName = () => {
    if (!user) return "";
    return user.fullName.split(" ")[0];
  };

  // Get user initials for avatar fallback
  const getUserInitials = () => {
    if (!user?.fullName) return "U";
    return user.fullName.split(" ")
      .map(n => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  };

  return (
    <header 
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        scrolled ? "bg-white shadow-sm" : "bg-white/80 backdrop-blur-sm"
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <a className="text-2xl font-bold text-primary-800">Blyss</a>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <a className={cn(
                "text-sm font-medium transition-colors hover:text-primary-700",
                location === "/" ? "text-primary-700" : "text-neutral-700"
              )}>
                Home
              </a>
            </Link>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className={cn(
                  "text-sm font-medium transition-colors hover:text-primary-700 flex items-center",
                  location.startsWith("/products") ? "text-primary-700" : "text-neutral-700"
                )}>
                  Products
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="w-48">
                <DropdownMenuItem asChild>
                  <Link href="/products">All Products</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                {PRODUCT_CATEGORIES.map((category) => (
                  <DropdownMenuItem key={category} asChild>
                    <Link href={`/products/${category.toLowerCase()}`}>{category}</Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {/* Cart Button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="relative"
              onClick={() => setCartOpen(true)}
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Button>

            {/* User Menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="p-1">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} alt={user.fullName} />
                      <AvatarFallback className="bg-primary-100 text-primary-700 text-xs">
                        {getUserInitials()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>
                    Hi, {formatDisplayName()}
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <a className="flex items-center">
                        <User className="mr-2 h-4 w-4" />
                        <span>Profile</span>
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/orders">
                      <a className="flex items-center">
                        <Package className="mr-2 h-4 w-4" />
                        <span>Orders</span>
                      </a>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => logoutMutation.mutate()}
                    className="text-red-500 focus:text-red-500"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button asChild variant="default" size="sm">
                <Link href="/auth">Sign In</Link>
              </Button>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-neutral-200">
          <div className="px-4 py-3 space-y-1">
            <Link href="/">
              <a 
                className={cn(
                  "block px-3 py-2 rounded-md text-base font-medium",
                  location === "/" ? "text-primary-700 bg-primary-50" : "text-neutral-700 hover:bg-neutral-50"
                )}
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </a>
            </Link>
            <Link href="/products">
              <a 
                className={cn(
                  "block px-3 py-2 rounded-md text-base font-medium",
                  location.startsWith("/products") ? "text-primary-700 bg-primary-50" : "text-neutral-700 hover:bg-neutral-50"
                )}
                onClick={() => setMobileMenuOpen(false)}
              >
                All Products
              </a>
            </Link>
            
            {/* Categories */}
            <div className="pl-3 border-l-2 border-neutral-100 mt-2 space-y-1">
              {PRODUCT_CATEGORIES.map((category) => (
                <Link key={category} href={`/products/${category.toLowerCase()}`}>
                  <a 
                    className="block px-3 py-1 rounded-md text-sm text-neutral-600 hover:bg-neutral-50"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {category}
                  </a>
                </Link>
              ))}
            </div>
            
            {user && (
              <>
                <Link href="/profile">
                  <a 
                    className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-50"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Profile
                  </a>
                </Link>
                <Link href="/orders">
                  <a 
                    className="block px-3 py-2 rounded-md text-base font-medium text-neutral-700 hover:bg-neutral-50"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Orders
                  </a>
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
