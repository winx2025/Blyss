import { Button } from "@/components/ui/button";
import { ProductImage } from "@/components/ui/product-image";
import { formatPrice, getDefaultProductImage } from "@/lib/utils";
import { Minus, Plus, Trash2 } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { Link } from "wouter";

interface CartItemProps {
  productId: number;
  title: string;
  price: number;
  imageUrl: string;
  quantity: number;
  stock: number;
}

export function CartItem({
  productId,
  title,
  price,
  imageUrl,
  quantity,
  stock,
}: CartItemProps) {
  const { updateQuantity, removeFromCart } = useCart();
  
  const increaseQuantity = () => {
    updateQuantity(productId, quantity + 1);
  };
  
  const decreaseQuantity = () => {
    updateQuantity(productId, quantity - 1);
  };
  
  const handleRemove = () => {
    removeFromCart(productId);
  };
  
  return (
    <div className="flex items-start gap-4 py-4">
      <Link href={`/product/${productId}`}>
        <a className="block flex-shrink-0">
          <ProductImage
            src={imageUrl || getDefaultProductImage(productId)}
            alt={title}
            className="h-20 w-20 object-cover rounded-md"
            fallbackSrc={getDefaultProductImage(productId)}
          />
        </a>
      </Link>
      
      <div className="flex-1 min-w-0">
        <Link href={`/product/${productId}`}>
          <a className="block">
            <h3 className="font-medium">{title}</h3>
          </a>
        </Link>
        <div className="mt-1 text-sm text-muted-foreground">
          Unit price: {formatPrice(price)}
        </div>
        
        <div className="flex items-center mt-2">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={decreaseQuantity}
            disabled={quantity <= 1}
          >
            <Minus className="h-3 w-3" />
          </Button>
          
          <span className="mx-3 text-sm">{quantity}</span>
          
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8"
            onClick={increaseQuantity}
            disabled={quantity >= stock}
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      
      <div className="flex flex-col items-end">
        <span className="font-medium">{formatPrice(price * quantity)}</span>
        
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleRemove}
          className="mt-2 text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
