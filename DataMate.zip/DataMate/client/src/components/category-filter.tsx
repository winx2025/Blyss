import React from "react";
import { PRODUCT_CATEGORIES } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CategoryFilterProps {
  selected?: string;
}

export default function CategoryFilter({ selected }: CategoryFilterProps) {
  return (
    <ScrollArea className="w-full">
      <div className="flex space-x-2 pb-2">
        <Button
          variant={!selected ? "default" : "outline"}
          size="sm"
          asChild
        >
          <Link href="/products">All</Link>
        </Button>
        
        {PRODUCT_CATEGORIES.map((category) => {
          const isSelected = selected?.toLowerCase() === category.toLowerCase();
          return (
            <Button
              key={category}
              variant={isSelected ? "default" : "outline"}
              size="sm"
              asChild
            >
              <Link href={`/products/${category.toLowerCase()}`}>
                {category}
              </Link>
            </Button>
          );
        })}
      </div>
    </ScrollArea>
  );
}
