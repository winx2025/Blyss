import { Product } from "@shared/schema";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { useCart } from "../lib/cart";
import { ShoppingBag, Heart } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    addItem({
      productId: product.id,
      title: product.title,
      price: product.price,
      imageUrl: product.imageUrl,
      quantity: 1,
      sellerId: product.sellerId
    });
  };

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md group">
      <Link href={`/product/${product.id}`}>
        <div className="relative">
          <div className="h-64 w-full overflow-hidden bg-neutral-100">
            <img
              src={product.imageUrl}
              alt={product.title}
              className="h-full w-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            />
          </div>
          <div className="absolute top-2 right-2 space-y-2">
            {product.featured && (
              <Badge variant="secondary" className="bg-primary-100 text-primary-800 hover:bg-primary-200">
                Featured
              </Badge>
            )}
            {product.stock <= 0 && (
              <Badge variant="destructive">Out of Stock</Badge>
            )}
          </div>
        </div>
        <CardContent className="p-4">
          <h3 className="font-medium text-neutral-900 line-clamp-1 mb-1">{product.title}</h3>
          <p className="text-lg font-semibold text-primary-700">${product.price.toFixed(2)}</p>
          <p className="text-sm text-neutral-500 line-clamp-2 mt-2 h-10">
            {product.description}
          </p>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex gap-2">
          <Button
            size="sm"
            className="flex-1"
            onClick={handleAddToCart}
            disabled={product.stock <= 0}
          >
            <ShoppingBag className="h-4 w-4 mr-1" />
            Add to Cart
          </Button>
          <Button size="sm" variant="outline" className="px-2">
            <Heart className="h-4 w-4" />
          </Button>
        </CardFooter>
      </Link>
    </Card>
  );
}
