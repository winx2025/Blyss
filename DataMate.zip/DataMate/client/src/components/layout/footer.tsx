import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-muted py-12 mt-16 border-t">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link href="/">
              <a className="font-semibold text-2xl text-primary">Blyss</a>
            </Link>
            <p className="mt-4 text-muted-foreground max-w-md">
              A marketplace for unique handmade goods, connecting talented artisans with 
              people who value authentic, one-of-a-kind items.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-foreground mb-4">Shop</h3>
            <ul className="space-y-2">
              {["Jewelry", "Home Decor", "Bags & Accessories", "Art", "Clothing"].map(category => (
                <li key={category}>
                  <Link href={`/shop?category=${encodeURIComponent(category)}`}>
                    <a className="text-muted-foreground hover:text-primary transition-colors">
                      {category}
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="font-medium text-foreground mb-4">Company</h3>
            <ul className="space-y-2">
              {[
                { label: "About Us", href: "#" },
                { label: "Contact", href: "#" },
                { label: "Policies", href: "#" },
                { label: "Seller Hub", href: "#" },
              ].map(link => (
                <li key={link.label}>
                  <Link href={link.href}>
                    <a className="text-muted-foreground hover:text-primary transition-colors">
                      {link.label}
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              &copy; {currentYear} Blyss Marketplace. All rights reserved.
            </p>
            
            <div className="flex space-x-6 mt-4 md:mt-0">
              {[
                { label: "Terms", href: "#" },
                { label: "Privacy", href: "#" },
                { label: "Cookies", href: "#" },
              ].map(link => (
                <Link key={link.label} href={link.href}>
                  <a className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    {link.label}
                  </a>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
