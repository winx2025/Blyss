import React from "react";
import { useCart } from "@/lib/cart";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Separator } from "@/components/ui/separator";
import { ShoppingBag, X, Trash2, Plus, Minus } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export function CartDrawer() {
  const { items, isOpen, setIsOpen, updateQuantity, removeItem, totalPrice } = useCart();

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent className="w-full sm:max-w-md flex flex-col h-full p-0">
        <SheetHeader className="px-6 py-4 border-b border-neutral-200">
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center">
              <ShoppingBag className="h-5 w-5 mr-2" />
              Shopping Cart
            </SheetTitle>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsOpen(false)}
              className="h-8 w-8"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <ShoppingBag className="h-12 w-12 text-neutral-300 mb-4" />
            <h3 className="text-lg font-medium text-neutral-900 mb-2">Your cart is empty</h3>
            <p className="text-sm text-neutral-500 mb-6">
              Looks like you haven't added any items to your cart yet.
            </p>
            <Button asChild onClick={() => setIsOpen(false)}>
              <Link href="/products">Browse Products</Link>
            </Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 p-6">
              <ul className="space-y-4">
                {items.map((item) => (
                  <li key={item.productId} className="flex gap-4">
                    <div className="h-16 w-16 bg-neutral-100 rounded-md overflow-hidden flex-shrink-0">
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-neutral-900 truncate mb-1">
                        {item.title}
                      </h4>
                      <p className="text-sm text-neutral-500 mb-2">
                        ${item.price.toFixed(2)}
                      </p>
                      
                      <div className="flex items-center">
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                          className="p-1 text-neutral-500 hover:text-neutral-700"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="px-2 text-sm">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                          className="p-1 text-neutral-500 hover:text-neutral-700"
                          aria-label="Increase quantity"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                        
                        <div className="ml-auto">
                          <button
                            onClick={() => removeItem(item.productId)}
                            className="p-1 text-neutral-400 hover:text-red-500"
                            aria-label="Remove item"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right font-medium">
                      ${(item.price * item.quantity).toFixed(2)}
                    </div>
                  </li>
                ))}
              </ul>
            </ScrollArea>
            
            <div className="border-t border-neutral-200 p-6">
              <div className="space-y-3 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Subtotal</span>
                  <span className="font-medium">${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-600">Shipping</span>
                  <span className="font-medium">
                    {totalPrice >= 50 ? "Free" : "$4.99"}
                  </span>
                </div>
                
                <Separator />
                
                <div className="flex justify-between text-base font-semibold">
                  <span>Total</span>
                  <span>
                    ${(totalPrice + (totalPrice >= 50 ? 0 : 4.99)).toFixed(2)}
                  </span>
                </div>
              </div>
              
              <div className="grid gap-3">
                <Button 
                  asChild 
                  onClick={() => setIsOpen(false)}
                  className="w-full"
                >
                  <Link href="/cart">View Cart</Link>
                </Button>
                <Button 
                  asChild 
                  onClick={() => setIsOpen(false)}
                  className="w-full"
                >
                  <Link href="/checkout">Checkout</Link>
                </Button>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
