import { cn } from "@/lib/utils";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { useState } from "react";

interface ProductImageProps {
  src: string;
  alt: string;
  className?: string;
  aspectRatio?: number;
  fill?: boolean;
  fallbackSrc?: string;
}

export function ProductImage({
  src,
  alt,
  className,
  aspectRatio = 1,
  fill = false,
  fallbackSrc,
  ...props
}: ProductImageProps & React.ImgHTMLAttributes<HTMLImageElement>) {
  const [error, setError] = useState(false);
  
  const handleError = () => {
    if (!fallbackSrc) return;
    setError(true);
  };

  const imageSrc = error && fallbackSrc ? fallbackSrc : src;

  if (fill) {
    return (
      <div className={cn("relative overflow-hidden rounded-md", className)}>
        <img
          src={imageSrc}
          alt={alt}
          onError={handleError}
          className="object-cover w-full h-full transition-all hover:scale-105"
          loading="lazy"
          {...props}
        />
      </div>
    );
  }

  return (
    <AspectRatio
      ratio={aspectRatio}
      className={cn("overflow-hidden rounded-md bg-muted", className)}
    >
      <img
        src={imageSrc}
        alt={alt}
        onError={handleError}
        className="object-cover w-full h-full transition-all hover:scale-105"
        loading="lazy"
        {...props}
      />
    </AspectRatio>
  );
}
