import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { 
  Menu,
  Search,
  ShoppingCart,
  User,
  LogOut,
  Package,
  Heart,
  ChevronDown,
  X,
  AlignJustify
} from "lucide-react";
import { 
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuLink,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export function Navbar() {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { totalItems } = useCart();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
    navigate("/");
  };
  
  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-primary" />
            <span className="text-2xl font-bold tracking-tight">Blyss</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <Link href="/">
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  Home
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link href="/products">
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  Shop
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    <span className="flex items-center">
                      Categories <ChevronDown className="ml-1 h-4 w-4" />
                    </span>
                  </NavigationMenuLink>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="center" className="w-48">
                  <DropdownMenuItem asChild>
                    <Link href="/products/Jewelry" className="w-full cursor-pointer">
                      Jewelry
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/products/Bags" className="w-full cursor-pointer">
                      Bags
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/products/Home Decor" className="w-full cursor-pointer">
                      Home Decor
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/products/Clothing" className="w-full cursor-pointer">
                      Clothing
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/products/Art" className="w-full cursor-pointer">
                      Art
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        {/* Search Form */}
        <form onSubmit={handleSearch} className="hidden md:flex w-full max-w-sm items-center gap-2 mx-4">
          <Input
            type="search"
            placeholder="Search handmade treasures..."
            className="border-primary/20 focus-visible:ring-primary/30"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button type="submit" size="icon" variant="ghost">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
        </form>

        {/* Desktop: User Menu & Cart */}
        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <>
              <Link href="/cart">
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  {totalItems > 0 && (
                    <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                      {totalItems}
                    </Badge>
                  )}
                  <span className="sr-only">Cart</span>
                </Button>
              </Link>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Avatar>
                      <AvatarImage src={user.avatar || undefined} alt={user.fullName} />
                      <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="flex items-center gap-2 p-2">
                    <div className="flex flex-col space-y-0.5">
                      <p className="text-sm font-medium">{user.fullName}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="flex cursor-pointer w-full">
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/orders" className="flex cursor-pointer w-full">
                      <Package className="mr-2 h-4 w-4" />
                      Orders
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Link href="/auth">
              <Button>Sign In</Button>
            </Link>
          )}
        </div>

        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <AlignJustify className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between mb-6">
                <Link href="/" className="flex items-center gap-2">
                  <Heart className="h-6 w-6 text-primary" />
                  <span className="text-xl font-bold">Blyss</span>
                </Link>
                <SheetClose className="rounded-full">
                  <X className="h-4 w-4" />
                  <span className="sr-only">Close</span>
                </SheetClose>
              </div>
              
              <form onSubmit={handleSearch} className="flex items-center gap-2 mb-6">
                <Input
                  type="search"
                  placeholder="Search..."
                  className="flex-1"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit" size="icon" variant="ghost">
                  <Search className="h-5 w-5" />
                  <span className="sr-only">Search</span>
                </Button>
              </form>
              
              <div className="space-y-1">
                <SheetClose asChild>
                  <Link href="/" className="block w-full p-2 rounded-md hover:bg-accent">Home</Link>
                </SheetClose>
                <SheetClose asChild>
                  <Link href="/products" className="block w-full p-2 rounded-md hover:bg-accent">Shop All</Link>
                </SheetClose>
                
                <h4 className="font-medium mt-4 mb-2 text-sm text-muted-foreground px-2">Categories</h4>
                <SheetClose asChild>
                  <Link href="/products/Jewelry" className="block w-full p-2 rounded-md hover:bg-accent">Jewelry</Link>
                </SheetClose>
                <SheetClose asChild>
                  <Link href="/products/Bags" className="block w-full p-2 rounded-md hover:bg-accent">Bags</Link>
                </SheetClose>
                <SheetClose asChild>
                  <Link href="/products/Home Decor" className="block w-full p-2 rounded-md hover:bg-accent">Home Decor</Link>
                </SheetClose>
                <SheetClose asChild>
                  <Link href="/products/Clothing" className="block w-full p-2 rounded-md hover:bg-accent">Clothing</Link>
                </SheetClose>
                <SheetClose asChild>
                  <Link href="/products/Art" className="block w-full p-2 rounded-md hover:bg-accent">Art</Link>
                </SheetClose>
              </div>
              
              <div className="mt-auto space-y-1">
                {user ? (
                  <>
                    <div className="flex items-center gap-2 p-2 border-t mt-4 pt-4">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.avatar || undefined} alt={user.fullName} />
                        <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <p className="text-sm font-medium">{user.fullName}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                    
                    <SheetClose asChild>
                      <Link href="/profile" className="flex items-center w-full p-2 rounded-md hover:bg-accent">
                        <User className="mr-2 h-4 w-4" />
                        Profile
                      </Link>
                    </SheetClose>
                    <SheetClose asChild>
                      <Link href="/orders" className="flex items-center w-full p-2 rounded-md hover:bg-accent">
                        <Package className="mr-2 h-4 w-4" />
                        Orders
                      </Link>
                    </SheetClose>
                    <SheetClose asChild>
                      <Link href="/cart" className="flex items-center w-full p-2 rounded-md hover:bg-accent">
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        Cart {totalItems > 0 && <Badge className="ml-2">{totalItems}</Badge>}
                      </Link>
                    </SheetClose>
                    <SheetClose asChild>
                      <button 
                        onClick={handleLogout}
                        className="flex items-center w-full p-2 rounded-md hover:bg-accent text-left"
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Logout
                      </button>
                    </SheetClose>
                  </>
                ) : (
                  <SheetClose asChild>
                    <Link href="/auth">
                      <Button className="w-full">Sign In</Button>
                    </Link>
                  </SheetClose>
                )}
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
