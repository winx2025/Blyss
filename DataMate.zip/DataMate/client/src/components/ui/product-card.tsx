import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { ShoppingCart } from "lucide-react";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, isPending } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();

  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to add items to your cart",
        variant: "destructive",
      });
      return;
    }

    addToCart({ productId: product.id, quantity: 1 });
  };

  return (
    <Card className="h-full flex flex-col">
      <Link href={`/product/${product.id}`}>
        <div className="aspect-square relative overflow-hidden rounded-t-lg cursor-pointer">
          <img
            src={product.imageUrl}
            alt={product.title}
            className="object-cover w-full h-full transition-transform duration-300 hover:scale-105"
          />
        </div>
      </Link>
      <CardContent className="flex-grow p-4">
        <Link href={`/product/${product.id}`}>
          <h3 className="font-medium text-base md:text-lg mb-1 hover:text-primary-600 cursor-pointer truncate">
            {product.title}
          </h3>
        </Link>
        <p className="text-xl font-semibold text-gray-900">${product.price.toFixed(2)}</p>
        <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
          {product.description}
        </p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full" 
          onClick={handleAddToCart} 
          disabled={isPending || product.stock < 1}
        >
          {product.stock < 1 ? (
            "Out of Stock"
          ) : (
            <>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
