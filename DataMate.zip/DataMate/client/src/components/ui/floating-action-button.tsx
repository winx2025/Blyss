import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const floatingActionButtonVariants = cva(
  "fixed z-50 flex h-14 w-14 items-center justify-center rounded-full shadow-lg transition-all",
  {
    variants: {
      position: {
        "bottom-right": "bottom-6 right-6",
        "bottom-left": "bottom-6 left-6",
        "top-right": "top-6 right-6",
        "top-left": "top-6 left-6",
      },
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/90",
        ghost: "bg-background/90 backdrop-blur hover:bg-accent",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
      },
    },
    defaultVariants: {
      position: "bottom-right",
      variant: "default",
    },
  }
);

export interface FloatingActionButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof floatingActionButtonVariants> {}

const FloatingActionButton = React.forwardRef<HTMLButtonElement, FloatingActionButtonProps>(
  ({ className, position, variant, ...props }, ref) => {
    return (
      <button
        className={cn(floatingActionButtonVariants({ position, variant, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
FloatingActionButton.displayName = "FloatingActionButton";

export { FloatingActionButton };