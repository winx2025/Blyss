import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Category } from "@shared/schema";

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link href={`/products/${category.id}`}>
      <Card className="overflow-hidden h-full cursor-pointer hover:shadow-md transition-shadow duration-300">
        <div className="aspect-video relative">
          <img
            src={category.imageUrl}
            alt={category.name}
            className="object-cover w-full h-full"
          />
          <div className="absolute inset-0 bg-black bg-opacity-30 flex items-end">
            <CardContent className="p-4 text-white">
              <h3 className="font-semibold text-lg">{category.name}</h3>
              <p className="text-sm text-white text-opacity-90 mt-1 line-clamp-2">
                {category.description}
              </p>
            </CardContent>
          </div>
        </div>
      </Card>
    </Link>
  );
}
