import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Menu, User, ShoppingBag, Home, Package, LayoutGrid, ClipboardList } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function MobileSidebar() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        setOpen(false);
      }
    });
  };

  const closeSheet = () => setOpen(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[350px] pr-0">
        <div className="flex flex-col h-full">
          <div className="px-1 py-4 border-b">
            <h2 className="text-2xl font-bold text-primary-600">Blyss</h2>
            <p className="text-sm text-muted-foreground">Handmade Marketplace</p>
          </div>

          <div className="flex-1 py-4">
            <nav className="flex flex-col space-y-1">
              <Link href="/" onClick={closeSheet}>
                <a className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${location === '/' ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                  <Home className="mr-3 h-5 w-5" />
                  <span>Home</span>
                </a>
              </Link>
              <Link href="/products" onClick={closeSheet}>
                <a className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${location.startsWith('/products') ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                  <LayoutGrid className="mr-3 h-5 w-5" />
                  <span>Browse Products</span>
                </a>
              </Link>
              {user ? (
                <>
                  <Link href="/cart" onClick={closeSheet}>
                    <a className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${location === '/cart' ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <ShoppingBag className="mr-3 h-5 w-5" />
                      <span>Shopping Cart</span>
                    </a>
                  </Link>
                  <Link href="/orders" onClick={closeSheet}>
                    <a className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${location === '/orders' ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <ClipboardList className="mr-3 h-5 w-5" />
                      <span>My Orders</span>
                    </a>
                  </Link>
                  <Link href="/profile" onClick={closeSheet}>
                    <a className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${location === '/profile' ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      <User className="mr-3 h-5 w-5" />
                      <span>My Profile</span>
                    </a>
                  </Link>
                </>
              ) : null}
            </nav>
          </div>

          <div className="py-4 border-t">
            {user ? (
              <div className="px-3">
                <div className="flex items-center mb-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar} alt={user.username} />
                    <AvatarFallback>{user.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="ml-3">
                    <p className="text-sm font-medium">{user.fullName}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full" onClick={handleLogout} disabled={logoutMutation.isPending}>
                  {logoutMutation.isPending ? "Logging out..." : "Logout"}
                </Button>
              </div>
            ) : (
              <div className="px-3 space-y-2">
                <Link href="/auth" onClick={closeSheet}>
                  <Button variant="default" className="w-full">
                    Sign In
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
