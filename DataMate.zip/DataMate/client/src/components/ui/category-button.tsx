import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface CategoryButtonProps {
  category: string;
  active?: boolean;
  className?: string;
}

export function CategoryButton({ category, active, className }: CategoryButtonProps) {
  const href = category === 'All' ? '/products' : `/products/${encodeURIComponent(category)}`;
  
  return (
    <Link href={href}>
      <Button
        variant={active ? "default" : "outline"}
        className={cn("rounded-full", className)}
      >
        {category}
      </Button>
    </Link>
  );
}
