import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash } from "lucide-react";
import { useCart } from "@/hooks/use-cart";
import { Link } from "wouter";
import { useState } from "react";

interface CartItemProps {
  id: number;
  productId: number;
  title: string;
  price: number;
  imageUrl: string;
  quantity: number;
}

export function CartItem({ id, productId, title, price, imageUrl, quantity }: CartItemProps) {
  const { updateCartItem, removeFromCart } = useCart();
  const [itemQuantity, setItemQuantity] = useState(quantity);

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuantity = parseInt(e.target.value);
    if (newQuantity > 0) {
      setItemQuantity(newQuantity);
    }
  };

  const handleUpdateQuantity = () => {
    if (itemQuantity !== quantity) {
      updateCartItem(id, itemQuantity);
    }
  };

  const handleRemove = () => {
    removeFromCart(id);
  };

  return (
    <div className="flex items-center py-4 space-x-4">
      <div className="flex-shrink-0 w-24 h-24 rounded-md overflow-hidden">
        <Link href={`/product/${productId}`}>
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover"
          />
        </Link>
      </div>
      <div className="flex-grow">
        <Link href={`/product/${productId}`}>
          <h3 className="font-medium text-gray-900 hover:text-primary-600">{title}</h3>
        </Link>
        <p className="mt-1 text-sm text-muted-foreground">
          ${price.toFixed(2)} each
        </p>
      </div>
      <div className="flex items-center space-x-2">
        <div className="w-20">
          <Input
            type="number"
            min="1"
            value={itemQuantity}
            onChange={handleQuantityChange}
            onBlur={handleUpdateQuantity}
            className="text-center"
          />
        </div>
        <div className="w-24 text-right">
          <p className="font-medium text-gray-900">${(price * quantity).toFixed(2)}</p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleRemove}
          className="text-gray-400 hover:text-red-500"
        >
          <Trash className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
