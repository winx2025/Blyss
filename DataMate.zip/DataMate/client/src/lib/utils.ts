import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format price to currency display
export function formatPrice(price: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(price);
}

// Format date to readable format
export function formatDate(date: Date | string) {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(date);
}

// Truncate text with ellipsis
export function truncateText(text: string, maxLength: number) {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

// Generate placeholder avatar using initials
export function getInitialsAvatar(name: string) {
  const initials = name
    .split(' ')
    .map(part => part.charAt(0))
    .join('')
    .toUpperCase()
    .slice(0, 2);
  
  return initials;
}

// Random pastel color generator for avatar backgrounds
export function getRandomPastelColor(seed: string) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = seed.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  const h = Math.abs(hash) % 360;
  return `hsl(${h}, 30%, 80%)`;
}

// Some placeholder images for products when no image is available
const DEFAULT_PRODUCT_IMAGES = [
  "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1549989476-69a92fa57c36?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1627308595229-7830a5c91f9f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1618220179428-22790b461013?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
];

// Get a default product image if none is provided
export function getDefaultProductImage(id: number) {
  return DEFAULT_PRODUCT_IMAGES[id % DEFAULT_PRODUCT_IMAGES.length];
}

// Placeholder avatar images for users
const DEFAULT_AVATAR_IMAGES = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=200&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
];

// Get a default avatar image if none is provided
export function getDefaultAvatarImage(id: number) {
  return DEFAULT_AVATAR_IMAGES[id % DEFAULT_AVATAR_IMAGES.length];
}

// Handmade jewelry images
export const JEWELRY_IMAGES = [
  "https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
];

// Handmade bags images
export const BAG_IMAGES = [
  "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1591561954557-26941169b49e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
];

// Handcrafted home decor images
export const HOME_DECOR_IMAGES = [
  "https://images.unsplash.com/photo-1616046229478-9901c5536a45?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
  "https://images.unsplash.com/photo-1526887593587-a307ea5d46b4?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
];

// Categorize a product image based on category
export function getCategoryImage(category: string, index: number = 0) {
  switch (category.toLowerCase()) {
    case 'jewelry':
      return JEWELRY_IMAGES[index % JEWELRY_IMAGES.length];
    case 'bags & accessories':
      return BAG_IMAGES[index % BAG_IMAGES.length];
    case 'home decor':
      return HOME_DECOR_IMAGES[index % HOME_DECOR_IMAGES.length];
    default:
      return getDefaultProductImage(index);
  }
}
