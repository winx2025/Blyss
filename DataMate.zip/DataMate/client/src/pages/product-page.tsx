import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Product } from "@shared/schema";
import { useCart } from "../lib/cart";
import { Button } from "@/components/ui/button";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { 
  Minus, 
  Plus, 
  ShoppingBag, 
  Truck,
  ArrowLeft,
  Loader2,
  Heart
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import EmptyState from "@/components/empty-state";

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const [quantity, setQuantity] = useState(1);
  const { addItem } = useCart();
  
  const { data: product, isLoading, error } = useQuery<Product>({
    queryKey: [`/api/products/${id}`],
    queryFn: async () => {
      const res = await fetch(`/api/products/${id}`);
      if (!res.ok) {
        throw new Error("Product not found");
      }
      return res.json();
    },
  });

  const handleAddToCart = () => {
    if (product) {
      addItem({
        productId: product.id,
        title: product.title,
        price: product.price,
        imageUrl: product.imageUrl,
        quantity,
        sellerId: product.sellerId
      });
    }
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const incrementQuantity = () => {
    if (product && quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <EmptyState 
        title="Product Not Found" 
        description="We couldn't find the product you're looking for."
        action={{
          label: "Browse all products",
          href: "/products"
        }}
      />
    );
  }

  return (
    <div className="bg-neutral-50 min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Breadcrumbs */}
        <Breadcrumb className="mb-4">
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href="/">Home</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href="/products">Products</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href={`/products/${product.category}`}>{product.category}</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink>{product.title}</BreadcrumbLink>
          </BreadcrumbItem>
        </Breadcrumb>

        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Product Image */}
            <div className="p-6">
              <div className="bg-neutral-50 rounded-lg overflow-hidden">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="w-full h-96 object-cover object-center"
                />
              </div>
            </div>
            
            {/* Product Details */}
            <div className="p-6 flex flex-col">
              <div className="mb-6">
                <Badge variant="outline" className="mb-2">
                  {product.category}
                </Badge>
                <h1 className="text-3xl font-bold text-neutral-900 mb-2">
                  {product.title}
                </h1>
                <p className="text-2xl font-medium text-primary-700 mb-4">
                  ${product.price.toFixed(2)}
                </p>
                <div className="prose text-neutral-600 mb-6">
                  <p>{product.description}</p>
                </div>

                {product.stock > 0 ? (
                  <div className="flex items-center text-sm text-green-600 mb-6">
                    <span className="flex h-2 w-2 bg-green-600 rounded-full mr-1"></span>
                    In Stock ({product.stock} available)
                  </div>
                ) : (
                  <div className="flex items-center text-sm text-red-600 mb-6">
                    <span className="flex h-2 w-2 bg-red-600 rounded-full mr-1"></span>
                    Out of Stock
                  </div>
                )}
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center mb-6">
                <label className="text-sm font-medium text-neutral-600 mr-4">
                  Quantity:
                </label>
                <div className="flex items-center border border-neutral-300 rounded-md">
                  <button
                    onClick={decrementQuantity}
                    disabled={quantity <= 1}
                    className="px-2 py-1 text-neutral-600 hover:bg-neutral-100 disabled:opacity-50"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="px-4 py-1 text-center w-12">{quantity}</span>
                  <button
                    onClick={incrementQuantity}
                    disabled={product.stock <= quantity}
                    className="px-2 py-1 text-neutral-600 hover:bg-neutral-100 disabled:opacity-50"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col space-y-3 mt-auto">
                <Button 
                  onClick={handleAddToCart} 
                  disabled={product.stock <= 0}
                  className="w-full"
                >
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Add to Cart
                </Button>
                
                <Button variant="outline" className="w-full">
                  <Heart className="mr-2 h-4 w-4" />
                  Add to Wishlist
                </Button>
              </div>

              {/* Shipping Info */}
              <div className="mt-8 pt-6 border-t border-neutral-200">
                <div className="flex items-start text-neutral-600">
                  <Truck className="h-5 w-5 mr-2 mt-0.5" />
                  <div>
                    <p className="text-sm">
                      Free shipping on orders over $50.
                      <br />
                      Estimated delivery: 3-5 business days
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <Button variant="ghost" asChild>
            <Link href="/products">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Products
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
