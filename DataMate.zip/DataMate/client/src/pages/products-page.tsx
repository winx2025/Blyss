import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { MobileSidebar } from "@/components/ui/mobile-sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { ProductCard } from "@/components/ui/product-card";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Search, ShoppingBag } from "lucide-react";
import { Category, Product } from "@shared/schema";

export default function ProductsPage() {
  const params = useParams();
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { totalItems } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("newest");

  // Get search param from URL if present
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const search = searchParams.get("search");
    if (search) {
      setSearchQuery(search);
    }
  }, []);

  const { data: categories = [], isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const selectedCategory = params.category ? parseInt(params.category) : undefined;

  // Construct query key based on filters
  const productsQueryKey = searchQuery
    ? [`/api/products?search=${searchQuery}`]
    : selectedCategory
    ? [`/api/products?category=${selectedCategory}`]
    : ["/api/products"];

  const { data: products = [], isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: productsQueryKey,
  });

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
    } else {
      navigate("/products");
    }
  };

  // Sort products based on selected option
  const sortedProducts = [...products].sort((a, b) => {
    switch (sortOption) {
      case "priceLow":
        return a.price - b.price;
      case "priceHigh":
        return b.price - a.price;
      case "newest":
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  // Get current category name for display
  const currentCategory = selectedCategory
    ? categories.find((c) => c.id === selectedCategory)?.name
    : searchQuery
    ? `Search results for "${searchQuery}"`
    : "All Products";

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <MobileSidebar />
              <Link href="/">
                <a className="flex-shrink-0">
                  <h1 className="text-2xl font-bold text-primary-600">Blyss</h1>
                </a>
              </Link>
              <nav className="hidden md:ml-6 md:flex md:space-x-8">
                <Link href="/">
                  <a className="text-gray-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Home
                  </a>
                </Link>
                <Link href="/products">
                  <a className="text-primary-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Products
                  </a>
                </Link>
              </nav>
            </div>
            <div className="hidden md:block flex-1 max-w-lg mx-4">
              <form onSubmit={handleSearch} className="relative">
                <Input
                  type="search"
                  placeholder="Search handmade products..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
              </form>
            </div>
            <div className="flex items-center">
              {user ? (
                <>
                  <Link href="/cart">
                    <a className="p-2 text-gray-600 hover:text-primary-600 relative">
                      <ShoppingBag className="h-6 w-6" />
                      {totalItems > 0 && (
                        <span className="absolute top-0 right-0 bg-primary-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                          {totalItems}
                        </span>
                      )}
                    </a>
                  </Link>
                  <div className="hidden md:flex ml-4 items-center">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} alt={user.username} />
                      <AvatarFallback>{user.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="ml-2">
                      <Button variant="ghost" size="sm" asChild>
                        <Link href="/profile">
                          <span className="text-sm font-medium">{user.fullName}</span>
                        </Link>
                      </Button>
                      <Button 
                        variant="link" 
                        size="sm" 
                        onClick={() => logoutMutation.mutate()}
                        disabled={logoutMutation.isPending}
                        className="text-xs text-muted-foreground"
                      >
                        Logout
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="hidden md:block">
                  <Link href="/auth">
                    <Button>Sign In</Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
          <div className="md:hidden py-3">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search handmade products..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            </form>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex">
          {/* Sidebar / Filters */}
          <div className="md:w-64 md:pr-8">
            <div className="hidden md:block mb-8">
              <h2 className="text-lg font-semibold mb-4">Categories</h2>
              <nav className="space-y-1">
                <Link href="/products">
                  <a className={`block px-3 py-2 rounded-md ${!selectedCategory ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                    All Products
                  </a>
                </Link>
                {categories.map((category) => (
                  <Link key={category.id} href={`/products/${category.id}`}>
                    <a className={`block px-3 py-2 rounded-md ${selectedCategory === category.id ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:bg-gray-100'}`}>
                      {category.name}
                    </a>
                  </Link>
                ))}
              </nav>
            </div>
          </div>

          {/* Product grid */}
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
              <h1 className="text-2xl font-bold">
                {currentCategory}
                {isLoadingProducts && (
                  <Loader2 className="inline-block ml-2 h-5 w-5 animate-spin text-primary-600" />
                )}
              </h1>
              
              <div className="mt-3 sm:mt-0 w-full sm:w-auto">
                <Select value={sortOption} onValueChange={setSortOption}>
                  <SelectTrigger className="w-full sm:w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="priceLow">Price: Low to High</SelectItem>
                      <SelectItem value="priceHigh">Price: High to Low</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Mobile categories */}
            <div className="md:hidden mb-6 overflow-x-auto">
              <div className="flex space-x-2 pb-2">
                <Link href="/products">
                  <a className={`inline-block px-3 py-1 rounded-full text-sm whitespace-nowrap ${!selectedCategory ? 'bg-primary-100 text-primary-800' : 'bg-gray-100 text-gray-800'}`}>
                    All
                  </a>
                </Link>
                {categories.map((category) => (
                  <Link key={category.id} href={`/products/${category.id}`}>
                    <a className={`inline-block px-3 py-1 rounded-full text-sm whitespace-nowrap ${selectedCategory === category.id ? 'bg-primary-100 text-primary-800' : 'bg-gray-100 text-gray-800'}`}>
                      {category.name}
                    </a>
                  </Link>
                ))}
              </div>
            </div>

            {isLoadingProducts ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-12 w-12 animate-spin text-primary-600" />
              </div>
            ) : sortedProducts.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-500 mb-6">Try adjusting your search or filter criteria</p>
                <Button asChild>
                  <Link href="/products">
                    <span>View All Products</span>
                  </Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} Blyss Marketplace. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
