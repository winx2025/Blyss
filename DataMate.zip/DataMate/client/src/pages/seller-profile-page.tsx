import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Loader2, ArrowLeft, Star, Mail, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { getDefaultAvatarImage, getInitialsAvatar, formatDate } from "@/lib/utils";
import { ProductGrid } from "@/components/products/product-grid";
import { User, Product } from "@shared/schema";

export default function SellerProfilePage() {
  const { id } = useParams<{ id: string }>();
  const sellerId = parseInt(id);

  // Fetch seller information
  const { data: seller, isLoading: isLoadingSeller } = useQuery<User>({
    queryKey: [`/api/users/${sellerId}`],
    enabled: !!sellerId && !isNaN(sellerId),
  });

  // Fetch seller's products
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: [`/api/products`, { sellerId }],
    enabled: !!sellerId && !isNaN(sellerId),
  });

  if (isLoadingSeller || isLoadingProducts) {
    return (
      <div className="container-custom py-16 flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!seller) {
    return (
      <div className="container-custom py-16 text-center">
        <h1 className="heading-xl mb-4">Seller Not Found</h1>
        <p className="text-muted-foreground mb-6">
          The seller you're looking for doesn't exist or has been removed.
        </p>
        <Button asChild>
          <Link href="/products">Browse Products</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container-custom py-8">
      <Button asChild variant="outline" size="sm" className="mb-6">
        <Link href="/products">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Products
        </Link>
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Seller Info Card */}
        <div>
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage 
                    src={seller.avatar || getDefaultAvatarImage(seller.id)} 
                    alt={seller.fullName || seller.username} 
                  />
                  <AvatarFallback>{getInitialsAvatar(seller.fullName || seller.username)}</AvatarFallback>
                </Avatar>
                <h1 className="heading-lg">{seller.fullName || seller.username}</h1>
                <p className="text-muted-foreground mb-4">Handmade Artisan</p>
                
                <div className="flex items-center mb-4">
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500 mr-1" />
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500 mr-1" />
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500 mr-1" />
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500 mr-1" />
                  <Star className="h-4 w-4 text-amber-500 fill-amber-500 mr-1" />
                  <span className="text-sm font-medium ml-1">5.0</span>
                  <span className="text-sm text-muted-foreground ml-1">(24 reviews)</span>
                </div>
                
                <Button className="w-full mb-4">
                  <Mail className="mr-2 h-4 w-4" />
                  Contact Seller
                </Button>
                
                <div className="space-y-2 w-full">
                  {seller.address && (
                    <div className="flex items-center text-sm">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{seller.address}</span>
                    </div>
                  )}
                  <div className="flex items-center text-sm">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>Member since {formatDate(new Date(Date.now() - 90 * 24 * 60 * 60 * 1000))}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h2 className="font-medium mb-3">Specialties</h2>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">Jewelry</Badge>
                <Badge variant="secondary">Handcrafted</Badge>
                <Badge variant="secondary">Sustainable</Badge>
                <Badge variant="secondary">Eco-friendly</Badge>
                <Badge variant="secondary">Artisanal</Badge>
              </div>
              
              <Separator className="my-4" />
              
              <h2 className="font-medium mb-3">About</h2>
              <p className="text-sm text-muted-foreground">
                {"I create unique handmade items with love and care. Each piece is crafted with attention to detail and sustainability in mind. My mission is to bring joy through beautiful handcrafted creations that last a lifetime."}
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Seller Products */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="products">
            <TabsList className="mb-6">
              <TabsTrigger value="products">Products ({products?.length || 0})</TabsTrigger>
              <TabsTrigger value="reviews">Reviews (24)</TabsTrigger>
            </TabsList>
            
            <TabsContent value="products">
              <ProductGrid 
                products={products || []} 
                isLoading={isLoadingProducts} 
                emptyMessage="This seller hasn't listed any products yet."
              />
            </TabsContent>
            
            <TabsContent value="reviews">
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i}>
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <Avatar>
                          <AvatarFallback>
                            {['JD', 'AM', 'TS'][i-1]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center mb-1">
                            <h3 className="font-medium mr-2">
                              {['Jane Doe', 'Alan Miller', 'Tanya Smith'][i-1]}
                            </h3>
                            <span className="text-xs text-muted-foreground">
                              {['3 days ago', '1 week ago', '2 weeks ago'][i-1]}
                            </span>
                          </div>
                          <div className="flex mb-2">
                            {Array(5).fill(0).map((_, i) => (
                              <Star key={i} className="h-4 w-4 text-amber-500 fill-amber-500" />
                            ))}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {[
                              "Absolutely gorgeous handmade items! The quality is exceptional and the seller was great to work with. Shipping was fast and everything arrived well-packaged.",
                              "I'm so impressed with the craftsmanship. You can tell each piece is made with care and attention to detail. Will definitely be ordering again!",
                              "Beautiful work and excellent customer service. The seller was very responsive to my questions and the final product exceeded my expectations."
                            ][i-1]}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}