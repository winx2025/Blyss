import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { ProductGrid } from "@/components/products/product-grid";
import { SearchFilter } from "@/components/products/search-filter";
import { useLocation } from "wouter";

export default function ShopPage() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  
  const category = searchParams.get("category");
  const searchQuery = searchParams.get("search");
  
  // Build query key based on filters
  const queryKey = ["/api/products"];
  if (category) queryKey.push(`category=${category}`);
  if (searchQuery) queryKey.push(`search=${searchQuery}`);
  
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey,
  });
  
  // Construct title based on filters
  let title = "All Products";
  if (category) title = category;
  if (searchQuery) title = `Search Results: "${searchQuery}"`;
  
  return (
    <div className="container-custom py-10">
      <div className="mb-8">
        <h1 className="heading-xl mb-2">{title}</h1>
        <p className="text-muted-foreground">
          {products?.length || 0} {products?.length === 1 ? "product" : "products"} found
        </p>
      </div>
      
      <SearchFilter />
      
      <ProductGrid 
        products={products || []} 
        isLoading={isLoading} 
        emptyMessage={
          searchQuery 
            ? `No products found matching "${searchQuery}"`
            : category 
              ? `No products found in ${category}`
              : "No products available yet"
        }
      />
    </div>
  );
}
