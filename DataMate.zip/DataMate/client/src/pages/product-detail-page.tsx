import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { MobileSidebar } from "@/components/ui/mobile-sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Category, Product, User } from "@shared/schema";
import { Loader2, Minus, Plus, Search, ShoppingBag, ShoppingCart } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetailPage() {
  const params = useParams<{ id: string }>();
  const productId = parseInt(params.id);
  const { user } = useAuth();
  const { addToCart, isPending: isCartPending } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const { totalItems } = useCart();

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: [`/api/products/${productId}`],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: seller } = useQuery<User>({
    queryKey: [`/api/users/${product?.sellerId}`],
    enabled: !!product,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery) {
      window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  const increaseQuantity = () => {
    if (product && quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleAddToCart = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to add items to your cart",
        variant: "destructive",
      });
      return;
    }

    if (product) {
      addToCart({ productId: product.id, quantity });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary-600" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
          <p className="text-gray-500 mb-6">The product you're looking for doesn't exist.</p>
          <Button asChild>
            <Link href="/products">
              <span>View All Products</span>
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  const category = categories.find((c) => c.id === product.categoryId);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <MobileSidebar />
              <Link href="/">
                <a className="flex-shrink-0">
                  <h1 className="text-2xl font-bold text-primary-600">Blyss</h1>
                </a>
              </Link>
              <nav className="hidden md:ml-6 md:flex md:space-x-8">
                <Link href="/">
                  <a className="text-gray-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Home
                  </a>
                </Link>
                <Link href="/products">
                  <a className="text-gray-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Products
                  </a>
                </Link>
              </nav>
            </div>
            <div className="hidden md:block flex-1 max-w-lg mx-4">
              <form onSubmit={handleSearch} className="relative">
                <Input
                  type="search"
                  placeholder="Search handmade products..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
              </form>
            </div>
            <div className="flex items-center">
              {user ? (
                <Link href="/cart">
                  <a className="p-2 text-gray-600 hover:text-primary-600 relative">
                    <ShoppingBag className="h-6 w-6" />
                    {totalItems > 0 && (
                      <span className="absolute top-0 right-0 bg-primary-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                        {totalItems}
                      </span>
                    )}
                  </a>
                </Link>
              ) : (
                <Link href="/auth">
                  <Button>Sign In</Button>
                </Link>
              )}
            </div>
          </div>
          <div className="md:hidden py-3">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search handmade products..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            </form>
          </div>
        </div>
      </header>

      {/* Breadcrumbs */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm text-gray-500">
            <ol className="list-none p-0 inline-flex">
              <li className="flex items-center">
                <Link href="/">
                  <a className="hover:text-primary-600">Home</a>
                </Link>
                <svg className="h-4 w-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </li>
              <li className="flex items-center">
                <Link href="/products">
                  <a className="hover:text-primary-600">Products</a>
                </Link>
                <svg className="h-4 w-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </li>
              {category && (
                <li className="flex items-center">
                  <Link href={`/products/${category.id}`}>
                    <a className="hover:text-primary-600">{category.name}</a>
                  </Link>
                  <svg className="h-4 w-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </li>
              )}
              <li className="text-gray-700 font-medium truncate">{product.title}</li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Product Details */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex -mx-4">
          {/* Product Image */}
          <div className="md:w-1/2 px-4 mb-8 md:mb-0">
            <div className="rounded-lg overflow-hidden bg-white shadow-sm">
              <img
                src={product.imageUrl}
                alt={product.title}
                className="w-full h-auto object-cover"
              />
            </div>
          </div>

          {/* Product Info */}
          <div className="md:w-1/2 px-4">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                {product.title}
              </h1>
              
              <div className="flex items-baseline mb-4">
                <span className="text-3xl font-bold text-gray-900">${product.price.toFixed(2)}</span>
                {product.stock > 0 ? (
                  <span className="ml-4 px-2 py-1 text-xs font-semibold text-green-800 bg-green-100 rounded-full">
                    In Stock
                  </span>
                ) : (
                  <span className="ml-4 px-2 py-1 text-xs font-semibold text-red-800 bg-red-100 rounded-full">
                    Out of Stock
                  </span>
                )}
              </div>

              <Separator className="my-4" />

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Description</h3>
                  <p className="mt-2 text-gray-700">{product.description}</p>
                </div>

                {category && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Category</h3>
                    <Link href={`/products/${category.id}`}>
                      <a className="mt-1 inline-block px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-800 hover:bg-primary-100 hover:text-primary-800">
                        {category.name}
                      </a>
                    </Link>
                  </div>
                )}

                {product.stock > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-900 mb-2">Quantity</h3>
                    <div className="flex items-center">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={decreaseQuantity}
                        disabled={quantity <= 1}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="mx-4 w-8 text-center">{quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={increaseQuantity}
                        disabled={quantity >= product.stock}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                      <span className="ml-4 text-sm text-gray-500">
                        {product.stock} available
                      </span>
                    </div>
                  </div>
                )}

                <div className="pt-4">
                  <Button
                    className="w-full"
                    size="lg"
                    onClick={handleAddToCart}
                    disabled={isCartPending || product.stock < 1}
                  >
                    {product.stock < 1 ? (
                      "Out of Stock"
                    ) : isCartPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Adding to Cart...
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="mr-2 h-4 w-4" />
                        Add to Cart
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {/* Seller info */}
            <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">About the Seller</h3>
              <div className="flex items-center">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={seller?.avatar} alt={seller?.username || "Seller"} />
                  <AvatarFallback>{seller?.username?.slice(0, 2).toUpperCase() || "S"}</AvatarFallback>
                </Avatar>
                <div className="ml-4">
                  <p className="text-base font-medium text-gray-900">{seller?.fullName || "Blyss Artisan"}</p>
                  <p className="text-sm text-gray-500">Handmade Artisan</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Similar Products */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">You Might Also Like</h2>
          {/* This would ideally be populated with similar products from the same category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {/* This is just a placeholder - in a real app, we would fetch similar products */}
            <div className="text-center text-gray-500 py-12 col-span-full">
              <p>Similar products would be shown here</p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} Blyss Marketplace. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
