import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { MobileSidebar } from "@/components/ui/mobile-sidebar";
import { Button } from "@/components/ui/button";
import { CartItem } from "@/components/ui/cart-item";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, ShoppingBag, AlertTriangle } from "lucide-react";

export default function CartPage() {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { cartItems, isLoading, totalItems, totalPrice, clearCart, isPending } = useCart();

  const handleClearCart = () => {
    if (window.confirm("Are you sure you want to clear your cart?")) {
      clearCart();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <MobileSidebar />
              <Link href="/">
                <a className="flex-shrink-0">
                  <h1 className="text-2xl font-bold text-primary-600">Blyss</h1>
                </a>
              </Link>
              <nav className="hidden md:ml-6 md:flex md:space-x-8">
                <Link href="/">
                  <a className="text-gray-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Home
                  </a>
                </Link>
                <Link href="/products">
                  <a className="text-gray-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Products
                  </a>
                </Link>
              </nav>
            </div>
            <div className="flex items-center">
              <Link href="/cart">
                <a className="p-2 text-primary-600 relative">
                  <ShoppingBag className="h-6 w-6" />
                  {totalItems > 0 && (
                    <span className="absolute top-0 right-0 bg-primary-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {totalItems}
                    </span>
                  )}
                </a>
              </Link>
              <div className="hidden md:flex ml-4 items-center">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.avatar} alt={user?.username} />
                  <AvatarFallback>{user?.username?.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="ml-2">
                  <Button variant="ghost" size="sm" asChild>
                    <Link href="/profile">
                      <span className="text-sm font-medium">{user?.fullName}</span>
                    </Link>
                  </Button>
                  <Button 
                    variant="link" 
                    size="sm" 
                    onClick={() => logoutMutation.mutate()}
                    disabled={logoutMutation.isPending}
                    className="text-xs text-muted-foreground"
                  >
                    Logout
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl md:text-3xl font-bold mb-8">Your Shopping Cart</h1>

        {isPending && (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
          </div>
        )}

        {!isPending && cartItems.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="flex justify-center mb-4">
              <ShoppingBag className="h-16 w-16 text-gray-300" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-gray-500 mb-6">
              Looks like you haven't added any products to your cart yet.
            </p>
            <Button size="lg" asChild>
              <Link href="/products">
                <span>Start Shopping</span>
              </Link>
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Cart Items List */}
            <div className="md:col-span-2">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold">Items ({totalItems})</h2>
                  {cartItems.length > 0 && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleClearCart}
                      disabled={isPending}
                      className="text-gray-500"
                    >
                      Clear Cart
                    </Button>
                  )}
                </div>

                {cartItems.map((item) => (
                  <div key={item.id}>
                    <CartItem
                      id={item.id}
                      productId={item.productId}
                      title={item.product.title}
                      price={item.product.price}
                      imageUrl={item.product.imageUrl}
                      quantity={item.quantity}
                    />
                    {cartItems.indexOf(item) < cartItems.length - 1 && (
                      <Separator className="my-2" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="md:col-span-1">
              <div className="bg-white rounded-lg shadow-sm p-6 sticky top-8">
                <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-medium">${totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span className="font-medium">$0.00</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax</span>
                    <span className="font-medium">$0.00</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>${totalPrice.toFixed(2)}</span>
                  </div>
                </div>

                <Button 
                  className="w-full mt-6" 
                  size="lg" 
                  asChild 
                  disabled={cartItems.length === 0 || isPending}
                >
                  <Link href="/checkout">
                    <span>Proceed to Checkout</span>
                  </Link>
                </Button>

                <div className="mt-4 text-xs text-gray-500 flex items-start space-x-2">
                  <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                  <p>
                    By proceeding to checkout, you agree to our terms of service and privacy policy.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-500 text-sm">
              © {new Date().getFullYear()} Blyss Marketplace. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
