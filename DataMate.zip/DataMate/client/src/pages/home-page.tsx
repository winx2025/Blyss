import { useQuery } from "@tanstack/react-query";
import { Loader2, Search, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CategoryCard } from "@/components/ui/category-card";
import { ProductCard } from "@/components/ui/product-card";
import { MobileSidebar } from "@/components/ui/mobile-sidebar";
import { Input } from "@/components/ui/input";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";
import { Category, Product } from "@shared/schema";
import { useCart } from "@/hooks/use-cart";

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { totalItems } = useCart();

  const { data: categories = [], isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: featuredProducts = [], isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <MobileSidebar />
              <Link href="/">
                <a className="flex-shrink-0">
                  <h1 className="text-2xl font-bold text-primary-600">Blyss</h1>
                </a>
              </Link>
              <nav className="hidden md:ml-6 md:flex md:space-x-8">
                <Link href="/">
                  <a className="text-primary-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Home
                  </a>
                </Link>
                <Link href="/products">
                  <a className="text-gray-600 hover:text-primary-500 px-3 py-2 text-sm font-medium">
                    Products
                  </a>
                </Link>
              </nav>
            </div>
            <div className="hidden md:block flex-1 max-w-lg mx-4">
              <form onSubmit={handleSearch} className="relative">
                <Input
                  type="search"
                  placeholder="Search handmade products..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
              </form>
            </div>
            <div className="flex items-center">
              {user ? (
                <>
                  <Link href="/cart">
                    <a className="p-2 text-gray-600 hover:text-primary-600 relative">
                      <ShoppingBag className="h-6 w-6" />
                      {totalItems > 0 && (
                        <span className="absolute top-0 right-0 bg-primary-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                          {totalItems}
                        </span>
                      )}
                    </a>
                  </Link>
                  <div className="hidden md:flex ml-4 items-center">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar} alt={user.username} />
                      <AvatarFallback>{user.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="ml-2">
                      <Button variant="ghost" size="sm" asChild>
                        <Link href="/profile">
                          <span className="text-sm font-medium">{user.fullName}</span>
                        </Link>
                      </Button>
                      <Button 
                        variant="link" 
                        size="sm" 
                        onClick={() => logoutMutation.mutate()}
                        disabled={logoutMutation.isPending}
                        className="text-xs text-muted-foreground"
                      >
                        Logout
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="hidden md:block">
                  <Link href="/auth">
                    <Button>Sign In</Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
          <div className="md:hidden py-3">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search handmade products..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            </form>
          </div>
        </div>
      </header>

      {/* Hero section */}
      <div className="relative">
        <div className="bg-gray-900 text-white py-24 px-4 sm:px-6 lg:px-8">
          <div className="container mx-auto max-w-5xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Discover Unique Handmade Treasures
            </h1>
            <p className="text-xl mb-8 max-w-3xl">
              Support artisans and add one-of-a-kind pieces to your collection. Every item tells a story of creativity and craftsmanship.
            </p>
            <Button size="lg" asChild>
              <Link href="/products">
                <span>Shop Now</span>
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Categories section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-6">Browse Categories</h2>
          {isLoadingCategories ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured products section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-6">Featured Products</h2>
          {isLoadingProducts ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-600" />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.slice(0, 8).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
          <div className="text-center mt-10">
            <Button variant="outline" size="lg" asChild>
              <Link href="/products">
                <span>View All Products</span>
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-center">Why Shop at Blyss</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center p-3 bg-primary-100 rounded-full mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Unique Products</h3>
              <p className="text-gray-600">Each item is handcrafted with care, ensuring you receive a one-of-a-kind piece.</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center p-3 bg-primary-100 rounded-full mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Support Artisans</h3>
              <p className="text-gray-600">Your purchase directly supports independent creators and small businesses.</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm text-center">
              <div className="inline-flex items-center justify-center p-3 bg-primary-100 rounded-full mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure Shopping</h3>
              <p className="text-gray-600">Shop with confidence through our secure platform with buyer protection.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Blyss</h3>
              <p className="text-gray-300">Discover unique handmade treasures from talented artisans across the globe.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Shop</h4>
              <ul className="space-y-2">
                <li><Link href="/products"><a className="text-gray-300 hover:text-white">All Products</a></Link></li>
                <li><Link href="/products/1"><a className="text-gray-300 hover:text-white">Jewelry</a></Link></li>
                <li><Link href="/products/2"><a className="text-gray-300 hover:text-white">Bags</a></Link></li>
                <li><Link href="/products/3"><a className="text-gray-300 hover:text-white">Home Decor</a></Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Account</h4>
              <ul className="space-y-2">
                <li><Link href="/profile"><a className="text-gray-300 hover:text-white">My Account</a></Link></li>
                <li><Link href="/orders"><a className="text-gray-300 hover:text-white">Orders</a></Link></li>
                <li><Link href="/cart"><a className="text-gray-300 hover:text-white">Cart</a></Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2">
                <li className="text-gray-300">Email: hello@blyss.com</li>
                <li className="text-gray-300">Phone: (555) 123-4567</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-300">© {new Date().getFullYear()} Blyss Marketplace. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
