import { createContext, ReactNode, useContext } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Cart, Product } from "@shared/schema";

type CartItem = Cart & { product: Product };

interface CartContextType {
  cartItems: CartItem[];
  isLoading: boolean;
  isPending: boolean;
  totalItems: number;
  totalPrice: number;
  addToCart: (item: { productId: number; quantity: number }) => void;
  updateCartItem: (id: number, quantity: number) => void;
  removeFromCart: (id: number) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();

  const {
    data: cartItems = [],
    isLoading,
    refetch,
  } = useQuery<CartItem[]>({
    queryKey: ["/api/cart"],
    retry: false,
  });

  const { mutate: addToCartMutation, isPending: isAddingToCart } = useMutation({
    mutationFn: async (item: { productId: number; quantity: number }) => {
      const res = await apiRequest("POST", "/api/cart", item);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: "Item has been added to your cart.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add to cart",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { mutate: updateCartItemMutation, isPending: isUpdatingCart } = useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      const res = await apiRequest("PUT", `/api/cart/${id}`, { quantity });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update cart",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { mutate: removeFromCartMutation, isPending: isRemovingFromCart } = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/cart/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Removed from cart",
        description: "Item has been removed from your cart.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to remove from cart",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { mutate: clearCartMutation, isPending: isClearingCart } = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", "/api/cart");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Cart cleared",
        description: "All items have been removed from your cart.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to clear cart",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const totalItems = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalPrice = cartItems.reduce(
    (acc, item) => acc + item.quantity * item.product.price,
    0
  );

  const isPending = isAddingToCart || isUpdatingCart || isRemovingFromCart || isClearingCart;

  return (
    <CartContext.Provider
      value={{
        cartItems,
        isLoading,
        isPending,
        totalItems,
        totalPrice,
        addToCart: (item) => addToCartMutation(item),
        updateCartItem: (id, quantity) => updateCartItemMutation({ id, quantity }),
        removeFromCart: (id) => removeFromCartMutation(id),
        clearCart: () => clearCartMutation(),
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
