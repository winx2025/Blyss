import { User, InsertUser, Product, InsertProduct, Category, InsertCategory, 
  Order, InsertOrder, OrderItem, InsertOrderItem, Review, InsertReview, Cart, InsertCart } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getProductsBySeller(sellerId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<boolean>;
  searchProducts(query: string): Promise<Product[]>;
  
  // Order operations
  getOrders(userId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order>;
  
  // OrderItem operations
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Review operations
  getProductReviews(productId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  
  // Cart operations
  getCartItems(userId: number): Promise<Cart[]>;
  getCartItemWithProduct(userId: number): Promise<(Cart & { product: Product })[]>;
  addToCart(cart: InsertCart): Promise<Cart>;
  updateCartItem(id: number, quantity: number): Promise<Cart>;
  removeFromCart(id: number): Promise<boolean>;
  clearCart(userId: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private reviews: Map<number, Review>;
  private carts: Map<number, Cart>;
  private userId: number;
  private categoryId: number;
  private productId: number;
  private orderId: number;
  private orderItemId: number;
  private reviewId: number;
  private cartId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.reviews = new Map();
    this.carts = new Map();
    this.userId = 1;
    this.categoryId = 1;
    this.productId = 1;
    this.orderId = 1;
    this.orderItemId = 1;
    this.reviewId = 1;
    this.cartId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Initialize with sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Create sample admin user
    this.createUser({
      username: "admin",
      password: "$scrypt$N=32768,r=8,p=1,maxmem=67108864$Q1hPMzZrQ05vNHdRb1lMMg$t2xJZnHRZSMpRqn6KQiHRu9cM/JYYBEXe/csuQUnx+o=", // password is "admin123"
      email: "admin@blyss.com",
      fullName: "Admin User",
      address: "123 Admin St",
      phone: "555-1234",
      avatar: "https://randomuser.me/api/portraits/women/1.jpg"
    });
    
    // Create sample categories
    const jewelry = this.createCategory({
      name: "Jewelry",
      description: "Handmade jewelry pieces crafted with love and care.",
      imageUrl: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?q=80&w=1000&auto=format&fit=crop"
    });
    
    const bags = this.createCategory({
      name: "Bags",
      description: "Unique handcrafted bags for every occasion.",
      imageUrl: "https://images.unsplash.com/photo-1598532163257-ae3c6b2524b6?q=80&w=1000&auto=format&fit=crop"
    });
    
    const homeDecor = this.createCategory({
      name: "Home Decor",
      description: "Beautiful handmade pieces to decorate your home.",
      imageUrl: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?q=80&w=1000&auto=format&fit=crop"
    });
    
    // Create sample products
    this.createProduct({
      title: "Handcrafted Beaded Necklace",
      description: "A beautiful beaded necklace made with natural stones and sterling silver.",
      price: 45.99,
      imageUrl: "https://images.unsplash.com/photo-1535632787350-4e68ef0ac584?q=80&w=1000&auto=format&fit=crop",
      categoryId: jewelry.id,
      sellerId: 1,
      stock: 10
    });
    
    this.createProduct({
      title: "Silver Charm Bracelet",
      description: "Elegant silver bracelet with hand-selected charms.",
      price: 29.99,
      imageUrl: "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?q=80&w=1000&auto=format&fit=crop",
      categoryId: jewelry.id,
      sellerId: 1,
      stock: 5
    });
    
    this.createProduct({
      title: "Artisan Gold Earrings",
      description: "Hand-forged gold earrings with a unique design.",
      price: 39.99,
      imageUrl: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?q=80&w=1000&auto=format&fit=crop",
      categoryId: jewelry.id,
      sellerId: 1,
      stock: 8
    });
    
    this.createProduct({
      title: "Canvas Tote Bag",
      description: "Sturdy canvas tote bag with hand-embroidered details.",
      price: 25.99,
      imageUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=1000&auto=format&fit=crop",
      categoryId: bags.id,
      sellerId: 1,
      stock: 12
    });
    
    this.createProduct({
      title: "Leather Crossbody Bag",
      description: "Handmade leather crossbody bag with adjustable strap.",
      price: 79.99,
      imageUrl: "https://images.unsplash.com/photo-1548863227-3af567fc3b27?q=80&w=1000&auto=format&fit=crop",
      categoryId: bags.id,
      sellerId: 1,
      stock: 3
    });
    
    this.createProduct({
      title: "Woven Market Basket",
      description: "Handwoven market basket made from sustainable materials.",
      price: 34.99,
      imageUrl: "https://images.unsplash.com/photo-1632852115888-ac5682efe1e1?q=80&w=1000&auto=format&fit=crop",
      categoryId: bags.id,
      sellerId: 1,
      stock: 7
    });
    
    this.createProduct({
      title: "Hand-painted Ceramic Vase",
      description: "Unique hand-painted ceramic vase perfect for fresh or dried flowers.",
      price: 49.99,
      imageUrl: "https://images.unsplash.com/photo-1623912279016-5a994a64f93b?q=80&w=1000&auto=format&fit=crop",
      categoryId: homeDecor.id,
      sellerId: 1,
      stock: 4
    });
    
    this.createProduct({
      title: "Macrame Wall Hanging",
      description: "Beautiful macrame wall hanging made with natural cotton rope.",
      price: 59.99,
      imageUrl: "https://images.unsplash.com/photo-1610464896103-0df701f0e53f?q=80&w=1000&auto=format&fit=crop",
      categoryId: homeDecor.id,
      sellerId: 1,
      stock: 6
    });
    
    this.createProduct({
      title: "Wooden Serving Board",
      description: "Handcrafted wooden serving board perfect for entertaining.",
      price: 42.99,
      imageUrl: "https://images.unsplash.com/photo-1607758328882-9bed7fb3d4cf?q=80&w=1000&auto=format&fit=crop",
      categoryId: homeDecor.id,
      sellerId: 1,
      stock: 9
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      isAdmin: false, 
      createdAt: now 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const updatedUser: User = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.categoryId === categoryId
    );
  }

  async getProductsBySeller(sellerId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.sellerId === sellerId
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const now = new Date();
    const product: Product = { ...insertProduct, id, createdAt: now };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, productData: Partial<InsertProduct>): Promise<Product> {
    const product = await this.getProduct(id);
    if (!product) {
      throw new Error(`Product with id ${id} not found`);
    }
    
    const updatedProduct: Product = { ...product, ...productData };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) => 
        product.title.toLowerCase().includes(lowercaseQuery) || 
        product.description.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Order methods
  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.userId === userId
    );
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    const now = new Date();
    const order: Order = { ...insertOrder, id, createdAt: now };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = await this.getOrder(id);
    if (!order) {
      throw new Error(`Order with id ${id} not found`);
    }
    
    const updatedOrder: Order = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // OrderItem methods
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === orderId
    );
  }

  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemId++;
    const orderItem: OrderItem = { ...insertOrderItem, id };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  // Review methods
  async getProductReviews(productId: number): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      (review) => review.productId === productId
    );
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.reviewId++;
    const now = new Date();
    const review: Review = { ...insertReview, id, createdAt: now };
    this.reviews.set(id, review);
    return review;
  }

  // Cart methods
  async getCartItems(userId: number): Promise<Cart[]> {
    return Array.from(this.carts.values()).filter(
      (cart) => cart.userId === userId
    );
  }

  async getCartItemWithProduct(userId: number): Promise<(Cart & { product: Product })[]> {
    const cartItems = await this.getCartItems(userId);
    return Promise.all(
      cartItems.map(async (cartItem) => {
        const product = await this.getProduct(cartItem.productId);
        if (!product) {
          throw new Error(`Product with id ${cartItem.productId} not found`);
        }
        return { ...cartItem, product };
      })
    );
  }

  async addToCart(insertCart: InsertCart): Promise<Cart> {
    // Check if item already exists in cart
    const existingCart = Array.from(this.carts.values()).find(
      (cart) => cart.userId === insertCart.userId && cart.productId === insertCart.productId
    );

    if (existingCart) {
      // Update existing cart item
      const updatedCart: Cart = {
        ...existingCart,
        quantity: existingCart.quantity + insertCart.quantity
      };
      this.carts.set(existingCart.id, updatedCart);
      return updatedCart;
    } else {
      // Create new cart item
      const id = this.cartId++;
      const cartItem: Cart = { ...insertCart, id };
      this.carts.set(id, cartItem);
      return cartItem;
    }
  }

  async updateCartItem(id: number, quantity: number): Promise<Cart> {
    const cartItem = this.carts.get(id);
    if (!cartItem) {
      throw new Error(`Cart item with id ${id} not found`);
    }
    
    const updatedCartItem: Cart = { ...cartItem, quantity };
    this.carts.set(id, updatedCartItem);
    return updatedCartItem;
  }

  async removeFromCart(id: number): Promise<boolean> {
    return this.carts.delete(id);
  }

  async clearCart(userId: number): Promise<boolean> {
    const cartItems = await this.getCartItems(userId);
    cartItems.forEach((item) => this.carts.delete(item.id));
    return true;
  }
}

export const storage = new MemStorage();
